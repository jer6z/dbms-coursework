-- Database Audit Logging and Intrusion Detection System (DB_IDS_Project)
-- Authors: Jorge E. Rosario, Adam Gold, Alan Young (MTSU)
-- Description: Complete SQL schema, documentation comments, and 50 test log rows.

BEGIN;

-- Drop everything to ensure a clean start if re-running
DROP TABLE IF EXISTS SecurityAlerts CASCADE;
DROP TABLE IF EXISTS SystemLogs CASCADE;
DROP TABLE IF EXISTS DetectionRules CASCADE;
DROP TABLE IF EXISTS Users CASCADE;

-- 1. Users Table
CREATE TABLE Users (
    user_id SERIAL PRIMARY KEY, 
    username VARCHAR(50) UNIQUE NOT NULL, 
    role VARCHAR(30) NOT NULL, 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. DetectionRules Table (Left blank for rule development)
CREATE TABLE DetectionRules (
    rule_id SERIAL PRIMARY KEY, 
    rule_name VARCHAR(100) NOT NULL, 
    threshold_value INT NOT NULL, 
    time_window_seconds INT NOT NULL, 
    is_active BOOLEAN DEFAULT TRUE
);

-- 3. SystemLogs Table
CREATE TABLE SystemLogs (
    log_id SERIAL PRIMARY KEY, 
    user_id INT REFERENCES Users(user_id), 
    event_type VARCHAR(50) NOT NULL, 
    status VARCHAR(20) NOT NULL, 
    query_text TEXT, 
    ip_address VARCHAR(45), 
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. SecurityAlerts Table (Left blank for trigger development)
CREATE TABLE SecurityAlerts (
    alert_id SERIAL PRIMARY KEY, 
    log_id INT REFERENCES SystemLogs(log_id), 
    rule_id INT REFERENCES DetectionRules(rule_id), 
    alert_message TEXT NOT NULL, 
    severity VARCHAR(20) NOT NULL, 
    triggered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Documentation Comments
COMMENT ON TABLE Users IS 'Stores system user accounts and their assigned roles for the database audit logging project.';
COMMENT ON TABLE SystemLogs IS 'Stores raw system event logs captured during database operations.';
COMMENT ON TABLE DetectionRules IS 'Stores intrusion detection rules and threshold parameters defined for anomaly detection.';
COMMENT ON TABLE SecurityAlerts IS 'Stores security alerts generated when system logs violate detection rules.';

COMMENT ON COLUMN Users.user_id IS 'Primary key for the user account.';
COMMENT ON COLUMN Users.username IS 'Unique username identifier.';
COMMENT ON COLUMN Users.role IS 'Assigned security role or access level of the user.';
COMMENT ON COLUMN Users.created_at IS 'Timestamp when the user account was created.';

COMMENT ON COLUMN SystemLogs.log_id IS 'Primary key for the individual log entry.';
COMMENT ON COLUMN SystemLogs.user_id IS 'Foreign key linking the log to the user who performed the action.';
COMMENT ON COLUMN SystemLogs.event_type IS 'The category of action performed (e.g., LOGIN, QUERY, EXECUTE).';
COMMENT ON COLUMN SystemLogs.status IS 'Outcome of the event (e.g., SUCCESS, FAILURE).';
COMMENT ON COLUMN SystemLogs.query_text IS 'The raw text of the query or session detail logged.';
COMMENT ON COLUMN SystemLogs.ip_address IS 'The source IP address from which the action originated.';
COMMENT ON COLUMN SystemLogs.timestamp IS 'Timestamp when the system log event occurred.';

COMMENT ON COLUMN DetectionRules.rule_id IS 'Primary key for the detection rule.';
COMMENT ON COLUMN DetectionRules.rule_name IS 'Descriptive name of the intrusion detection rule.';
COMMENT ON COLUMN DetectionRules.threshold_value IS 'Numeric limit or threshold required to trigger the rule.';
COMMENT ON COLUMN DetectionRules.time_window_seconds IS 'Time interval window in seconds over which the threshold is evaluated.';
COMMENT ON COLUMN DetectionRules.is_active IS 'Boolean flag indicating whether the rule is currently active.';

COMMENT ON COLUMN SecurityAlerts.alert_id IS 'Primary key for the generated security alert.';
COMMENT ON COLUMN SecurityAlerts.log_id IS 'Foreign key linking the alert to the specific violating system log.';
COMMENT ON COLUMN SecurityAlerts.rule_id IS 'Foreign key linking the alert to the detection rule that was violated.';
COMMENT ON COLUMN SecurityAlerts.alert_message IS 'Description message detailing why the alert was triggered.';
COMMENT ON COLUMN SecurityAlerts.severity IS 'Severity classification of the security alert (e.g., LOW, MEDIUM, HIGH, CRITICAL).';
COMMENT ON COLUMN SecurityAlerts.triggered_at IS 'Timestamp when the security alert was generated.';

-- Seed Users
INSERT INTO Users (user_id, username, role) VALUES 
(1, 'admin_jorge', 'Administrator'),
(2, 'dev_adam', 'Developer'),
(3, 'analyst_alan', 'Security Analyst'),
(4, 'guest_user', 'Guest'),
(5, 'service_bot', 'ServiceAccount')
ON CONFLICT (user_id) DO NOTHING;

-- Seed 50 Lines of System Logs
INSERT INTO SystemLogs (user_id, event_type, status, query_text, ip_address) VALUES 
(1, 'LOGIN', 'SUCCESS', 'SELECT * FROM Users;', '192.168.1.10'),
(2, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs;', '192.168.1.15'),
(3, 'LOGIN', 'FAILURE', 'INVALID CREDENTIALS', '10.0.0.5'),
(3, 'LOGIN', 'FAILURE', 'INVALID CREDENTIALS', '10.0.0.5'),
(3, 'LOGIN', 'FAILURE', 'INVALID CREDENTIALS', '10.0.0.5'),
(3, 'LOGIN', 'FAILURE', 'INVALID CREDENTIALS', '10.0.0.5'),
(3, 'LOGIN', 'FAILURE', 'INVALID CREDENTIALS', '10.0.0.5'),
(4, 'QUERY', 'SUCCESS', 'SELECT username FROM Users;', '172.16.0.4'),
(5, 'EXECUTE', 'SUCCESS', 'CALL update_metrics();', '127.0.0.1'),
(1, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs;', '192.168.1.10'),
(2, 'QUERY', 'SUCCESS', 'SELECT COUNT(*) FROM Users;', '192.168.1.15'),
(3, 'LOGIN', 'SUCCESS', 'Valid login session started.', '192.168.1.20'),
(4, 'QUERY', 'FAILURE', 'SELECT * FROM SecretTable;', '172.16.0.4'),
(2, 'INSERT', 'SUCCESS', 'INSERT INTO SystemLogs (user_id, event_type, status) VALUES (2, ''TEST'', ''SUCCESS'');', '192.168.1.15'),
(1, 'UPDATE', 'SUCCESS', 'UPDATE Users SET role = ''Admin'' WHERE user_id = 2;', '192.168.1.10'),
(4, 'QUERY', 'SUCCESS', 'SELECT CURRENT_DATE;', '172.16.0.4'),
(5, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs LIMIT 10;', '127.0.0.1'),
(3, 'QUERY', 'SUCCESS', 'SELECT * FROM Users;', '192.168.1.20'),
(2, 'DELETE', 'FAILURE', 'DROP TABLE Users;', '192.168.1.15'),
(1, 'QUERY', 'SUCCESS', 'SELECT version();', '192.168.1.10'),
(3, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs WHERE status = ''FAILURE'';', '192.168.1.20'),
(4, 'LOGIN', 'SUCCESS', 'Guest login granted.', '172.16.0.4'),
(2, 'QUERY', 'SUCCESS', 'SELECT pg_size_pretty(pg_database_size(''db_ids_project''));', '192.168.1.15'),
(5, 'EXECUTE', 'SUCCESS', 'REFRESH MATERIALIZED VIEW logs_summary;', '127.0.0.1'),
(1, 'QUERY', 'SUCCESS', 'SELECT * FROM pg_stat_activity;', '192.168.1.10'),
(3, 'UPDATE', 'SUCCESS', 'UPDATE Users SET username = ''analyst_alan_new'' WHERE user_id = 3;', '192.168.1.20'),
(4, 'QUERY', 'FAILURE', 'SELECT * FROM NonExistentTable;', '172.16.0.4'),
(2, 'QUERY', 'SUCCESS', 'SELECT column_name FROM information_schema.columns;', '192.168.1.15'),
(1, 'INSERT', 'SUCCESS', 'INSERT INTO Users (username, role) VALUES (''new_user'', ''Guest'');', '192.168.1.10'),
(5, 'QUERY', 'SUCCESS', 'SELECT NOW();', '127.0.0.1'),
(3, 'QUERY', 'SUCCESS', 'SELECT user_id, role FROM Users;', '192.168.1.20'),
(4, 'QUERY', 'FAILURE', 'DELETE FROM Users;', '172.16.0.4'),
(2, 'QUERY', 'SUCCESS', 'SELECT current_user;', '192.168.1.15'),
(1, 'QUERY', 'SUCCESS', 'SELECT inet_client_addr();', '192.168.1.10'),
(3, 'LOGIN', 'LOGOUT', 'User session terminated normally.', '192.168.1.20'),
(4, 'LOGOUT', 'LOGOUT', 'User session terminated normally.', '172.16.0.4'),
(2, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs ORDER BY timestamp DESC LIMIT 5;', '192.168.1.15'),
(5, 'EXECUTE', 'SUCCESS', 'VACUUM ANALYZE SystemLogs;', '127.0.0.1'),
(1, 'QUERY', 'SUCCESS', 'SELECT table_name FROM information_schema.tables;', '192.168.1.10'),
(3, 'LOGIN', 'SUCCESS', 'Session restarted.', '192.168.1.25'),
(3, 'QUERY', 'SUCCESS', 'SELECT * FROM SystemLogs WHERE user_id = 3;', '192.168.1.25'),
(2, 'QUERY', 'SUCCESS', 'SELECT table_schema, table_name FROM information_schema.tables;', '192.168.1.15'),
(4, 'QUERY', 'FAILURE', 'DROP TABLE SystemLogs;', '172.16.0.99'),
(1, 'QUERY', 'SUCCESS', 'SELECT datname FROM pg_database;', '192.168.1.10'),
(5, 'QUERY', 'SUCCESS', 'SELECT count(*) FROM SystemLogs WHERE status = ''FAILURE'';', '127.0.0.1'),
(3, 'QUERY', 'SUCCESS', 'SELECT * FROM Users WHERE role = ''Administrator'';', '192.168.1.25'),
(2, 'QUERY', 'SUCCESS', 'SELECT routine_name FROM information_schema.routines;', '192.168.1.15'),
(4, 'QUERY', 'FAILURE', 'ALTER TABLE Users DROP COLUMN role;', '172.16.0.99'),
(1, 'QUERY', 'SUCCESS', 'SELECT current_database();', '192.168.1.10'),
(5, 'EXECUTE', 'SUCCESS', 'CHECKPOINT;', '127.0.0.1');

COMMIT;
